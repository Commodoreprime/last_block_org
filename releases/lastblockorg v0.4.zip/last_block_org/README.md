This is the dev branch. Where development happens. 
Releases for the pack are located in the 'master' branch.

change log structure:

Summary: 

v#.# - Content update #
