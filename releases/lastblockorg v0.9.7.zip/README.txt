v0.9.7

Quickie install process:
1. unzip (optional)
2. copy or move the "last_block_org" folder to \saves\<world_name>\datapacks
3. Done. type /reload or restart world to get the goodness!
