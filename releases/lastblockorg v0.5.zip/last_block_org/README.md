# last_block_org
This is where the datapack is stored for LBO

This is a datapack for the server Craft Manor

Releases are located here: https://github.com/Commodoreprime/last_block_org/tree/master/releases.
Latest build is v0.3b
This master branch is for holding releases of the pack. development happens in the dev branch

If you want to copy this datapack and change it however you want, go right on ahead! Just give credit with a link to this repo if you could please.
